export interface LabelProps {
  text: string;
  color?: string;
}
