export interface TextProps {
  content: string;
  size?: string;
  color?: string;
}
