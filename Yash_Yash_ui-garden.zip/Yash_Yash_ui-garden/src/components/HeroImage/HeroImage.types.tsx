export interface HeroImageProps {
  src: string;
  alt: string;
  overlayText?: string;
}
