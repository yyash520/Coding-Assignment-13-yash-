export interface TableHeaderProps {
  headers: string[];
}
