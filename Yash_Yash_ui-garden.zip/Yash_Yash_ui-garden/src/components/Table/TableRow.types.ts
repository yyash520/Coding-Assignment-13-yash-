export interface TableRowProps {
  row: string[];
}
