export interface TableFooterProps {
  footer: string[];
}
