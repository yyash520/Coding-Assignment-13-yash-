export interface CardProps {
    title: string;
    content: string;
    imageSrc?: string;
    altText?: string;
    footer?: string;
  }
